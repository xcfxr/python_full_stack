from django.shortcuts import render


from rest_framework.views import APIView
from rest_framework.response import Response

from rest_framework_jwt.authentication import JSONWebTokenAuthentication
from api.auth import MyToken
class BookView(APIView):
    authentication_classes = [MyToken,]
    def get(self,request):
        print(request.user.email)
        return Response('ok')