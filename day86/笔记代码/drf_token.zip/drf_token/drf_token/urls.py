
from django.contrib import admin
from django.urls import path


from rest_framework_jwt.views import ObtainJSONWebToken,VerifyJSONWebToken,RefreshJSONWebToken,obtain_jwt_token
# 基类：JSONWebTokenAPIView继承了APIView，
# ObtainJSONWebToken,VerifyJSONWebToken,RefreshJSONWebToken都继承了JSONWebTokenAPIView
'''
obtain_jwt_token = ObtainJSONWebToken.as_view()
refresh_jwt_token = RefreshJSONWebToken.as_view()
verify_jwt_token = VerifyJSONWebToken.as_view()
'''
from api import views
urlpatterns = [
    path('admin/', admin.site.urls),
    # path('login/', ObtainJSONWebToken.as_view()),
    path('login/', obtain_jwt_token),
    path('books/', views.BookView.as_view()),
]
